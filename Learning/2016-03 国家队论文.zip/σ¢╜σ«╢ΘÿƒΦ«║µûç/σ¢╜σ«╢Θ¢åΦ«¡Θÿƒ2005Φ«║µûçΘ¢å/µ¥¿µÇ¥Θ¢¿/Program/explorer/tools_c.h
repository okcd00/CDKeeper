#ifndef TOOLS_C_LIB
#define TOOLS_C_LIB

const double eps = 1e-2;

double Start();
double Ask(double posi);
void Answer(double res);

#endif

